exports.baseLevelPath = require.resolve('../../.bem/levels/bundles.js');
