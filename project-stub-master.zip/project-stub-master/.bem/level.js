exports.baseLevelPath = require.resolve('bem/lib/levels/project');
