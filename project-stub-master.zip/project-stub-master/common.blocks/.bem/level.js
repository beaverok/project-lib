exports.baseLevelPath = require.resolve('../../.bem/levels/blocks.js');
