<?
$MESS["T_IBLOCK_DESC_ASC"] = "По возрастанию";
$MESS["T_IBLOCK_DESC_DESC"] = "По убыванию";
$MESS["T_IBLOCK_DESC_FID"] = "ID";
$MESS["T_IBLOCK_DESC_FNAME"] = "Название";
$MESS["T_IBLOCK_DESC_FACT"] = "Дата начала активности";
$MESS["T_IBLOCK_DESC_FSORT"] = "Сортировка";
$MESS["T_IBLOCK_DESC_FTSAMP"] = "Дата последнего изменения";
$MESS["T_IBLOCK_DESC_IBORD1"] = "Поле для сортировки элементов";
$MESS["T_IBLOCK_DESC_IBBY1"] = "Направление для сортировки элементов";
$MESS["T_IBLOCK_DESC_LIST_ID"] = "Код информационного блока";
$MESS["T_IBLOCK_DESC_LIST_TYPE"] = "Тип информационного блока (используется только для проверки)";
$MESS["T_IBLOCK_DESC_LIST_CONT"] = "Количество элементов на странице";
$MESS["T_IBLOCK_PROPERTY"] = "Свойства";
$MESS["IBLOCK_FIELD"] = "Поля";
$MESS["T_IBLOCK_DESC_CHECK_DATES"] = "Показывать только активные на данный момент элементы";
$MESS["CP_BNL_CACHE_GROUPS"] = "Учитывать права доступа";
?>